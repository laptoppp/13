package com.example.ese11smsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn;
    EditText phone,sms;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn=findViewById(R.id.btn);
        phone=findViewById(R.id.phone);
        sms=findViewById(R.id.sms);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int permissionGranted = PackageManager.PERMISSION_GRANTED;

                if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.SEND_SMS)== PackageManager.PERMISSION_GRANTED)
                {
                     sendsms();
                }
                else
                {
                    Toast.makeText(MainActivity.this, "permission not granted", Toast.LENGTH_SHORT).show();
                    ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.SEND_SMS},100);
                    


                }
            }
        });


    }

    private void sendsms()
    {
        String a=phone.getText().toString();
        String b=sms.getText().toString();


            SmsManager smsManager=  SmsManager.getDefault();
            smsManager.sendTextMessage(a,null,b,null,null);
            Toast.makeText(this, "mesage sent", Toast.LENGTH_LONG).show();

    }
}